package org.jspiders.practiceApp.tester;
import org.jspiders.practiceApp.dao.TripDDAO;
import org.jspiders.practiceApp.dto.TripDTO;

public class TesterApp {
	public static void main(String[] args) {
		// save operation
		/*TripDTO tripDTO=new TripDTO();
		//tripDTO.setId(4);
		tripDTO.setDes("thailand");
		tripDTO.setPrice(12000);
		tripDTO.setPincode(015076);
		TripDDAO tripDAO=new TripDDAO();
		tripDAO.saveTrip(tripDTO);*/

		// read operation
		/* TripDDAO tripDAO=new TripDDAO();

		TripDTO tripDTO=tripDAO.getTripById(1);
		System.out.println("destination "+tripDTO.getDes());
		System.out.println("price "+tripDTO.getPrice()); */

		// update operation
		/*TripDDAO tripDAO=new TripDDAO();
	     tripDAO.updateTripById(1, 900500);
		System.out.println("updated");*/

		// fetchExpenses based on destination

		TripDDAO tripDAO=new TripDDAO();
		double expenses = tripDAO.fetchExpensesByDestination("goa");
		System.out.println("Expenses for the trip would be: " + expenses);

		int noOfRowsUpdated = tripDAO.updateExpensesByDestination("wayanad", 15000);
		System.out.println("No of rows affected: " + noOfRowsUpdated);



	}

}
