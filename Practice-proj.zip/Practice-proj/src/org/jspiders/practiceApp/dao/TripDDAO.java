package org.jspiders.practiceApp.dao;


import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.jspiders.practiceApp.dto.TripDTO;

import com.jspiders.foodApp.util.HibernateUtil;

public class TripDDAO {
	SessionFactory sessionFactory=HibernateUtil.getSessionFactory();
public void saveTrip(TripDTO tripDTO)
{
 	Session session=sessionFactory.openSession();
 	Transaction transaction=session.beginTransaction();
 	
 	session.save(tripDTO);
 	transaction.commit();
 	session.close();
}
public TripDTO getTripById(int primarykey)
{
	Session session=sessionFactory.openSession();
	TripDTO tripDTO=session.get(TripDTO.class, new Integer(primarykey));
	session.close();
	return tripDTO;
}

public TripDTO updateTripById(int primarykey,double price)
{
	Session session=null;
	Transaction transaction=null;
	TripDTO tripDTO=null;
	try {
	session=sessionFactory.openSession();
	transaction=session.beginTransaction();
	tripDTO=session.get(TripDTO.class, new Integer(primarykey));
	if(tripDTO!=null)
	{
		tripDTO.setPrice(price);
		session.update(tripDTO);
	}
	transaction.commit();
}catch(HibernateException e)
	{
	e.printStackTrace();
	transaction.rollback();
	}
	finally {
		if(session!=null)
		session.close();
	}
	return tripDTO;
}

}
