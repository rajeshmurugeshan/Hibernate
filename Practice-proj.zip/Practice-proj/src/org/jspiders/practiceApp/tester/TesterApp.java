package org.jspiders.practiceApp.tester;
import org.jspiders.practiceApp.dao.TripDDAO;
import org.jspiders.practiceApp.dto.TripDTO;

public class TesterApp {
	public static void main(String[] args) {
// save operation
		/*TripDTO tripDTO=new TripDTO();
		tripDTO.setId(4);
		tripDTO.setDes("wayanad");
		tripDTO.setPrice(4567);
		tripDTO.setPincode(659076);
		TripDDAO tripDAO=new TripDDAO();
		tripDAO.saveTrip(tripDTO);*/
		
		// read operation
		/* TripDDAO tripDAO=new TripDDAO();
		
		TripDTO tripDTO=tripDAO.getTripById(1);
		System.out.println("destination "+tripDTO.getDes());
		System.out.println("price "+tripDTO.getPrice()); */
		
		// update operation
	 TripDDAO tripDAO=new TripDDAO();
	 tripDAO.updateTripById(2, 4500);
		
		
		
		
	}

}
