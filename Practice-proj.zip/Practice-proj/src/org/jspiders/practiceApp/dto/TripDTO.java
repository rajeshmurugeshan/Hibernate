package org.jspiders.practiceApp.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="trip_table")

public class TripDTO implements Serializable
{
	public  TripDTO()
	{
		System.out.println("tripDto object created");
	}
	@Id
	@Column(name="t_id")
	private int id;
	@Column(name="t_destination")
	private String des;
	@Column(name="t_expenses")
	private double price;
	@Column(name="t_pincode")
	private long pincode;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDes() {
		return des;
	}
	public void setDes(String des) {
		this.des = des;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public long getPincode() {
		return pincode;
	}
	public void setPincode(long pincode) {
		this.pincode = pincode;
	}
	
}
